import logging
import json
import os

import azure.functions as func
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential



def query_order_table(order_id: str) -> dict:
    """A mock of an external database, to simplify the scenario. In the real world,
    This would be a connection to some kind of external database which keeps track
    of deliveries and their status."""
    orders = [
        {"order_id": "000001", "tracking_code": "657637", "status": "Development", "shipped": False},
        {"order_id": "000002", "tracking_code": "976545", "status": "Testing", "shipped": False},
        {"order_id": "000003", "tracking_code": "624555", "status": "Shipped", "shipped": True},
        {"order_id": "000004", "tracking_code": "135646", "status": "Testing", "shipped": False},
        {"order_id": "000005", "tracking_code": "164378", "status": "Development", "shipped": False},
        {"order_id": "000006", "tracking_code": "789123", "status": "Development", "shipped": False},
        {"order_id": "000007", "tracking_code": "456789", "status": "Testing", "shipped": False},
        {"order_id": "000008", "tracking_code": "123456", "status": "Shipped", "shipped": True},
        {"order_id": "000009", "tracking_code": "654321", "status": "Development", "shipped": False},
        {"order_id": "000010", "tracking_code": "987654", "status": "Testing", "shipped": False},
    ]
    for order in orders:
        if order["order_id"] == order_id:
            return order
    raise ResourceNotFoundError

def fetch_order_details(order_id: str):
    """Function to fetch shipping details based on orderId."""
    try:
        order_details = query_order_table(order_id)
    except ResourceNotFoundError:
        logging.info("Failed to find entity in table storage")
        order_details = None
    return order_details


def get_order_status(order_id: str):
    """Function to retrieve the latest status of an order"""
    logging.info("Fetching the latest status of order %s.", order_id)
    # Setting default value
    return_time = f"The order with orderId {order_id} doesn't exist. Please check the provided orderId."
    order_details = fetch_order_details(order_id)
    if order_details is not None:
        match order_details["status"]:
            case "Development":
                return_time = f"Order {order_id} is currently in development. Our team will contact you when your software is ready to begin testing.."
            case "Testing":
                return_time = f"Order {order_id} is currently being tested. Once testing finishes, the product will be shipped to the hub."
            case "Shipped":
                return_time = f"Order {order_id} has already been shipped and can be downloaded from the hub."
    logging.info(return_time)
    return return_time


def get_order_delivery_details(order_id: str, tracking_code: str):
    """Function to retrieve the delivery details of an order"""
    logging.info(
        "Details of %s requested, validating supplied tracking code %s...",
        order_id,
        tracking_code,
    )
    order_details = fetch_order_details(order_id)
    if order_details is not None:
        supplied_correct_tracking_code = eval(
            "%s == %s" % (order_details["tracking_code"], tracking_code)
        )
        if supplied_correct_tracking_code:
            logging.info(
                "The supplied tracking code is correct. Returning order details!"
            )
            delivery_details = json.dumps(order_details)
        else:
            logging.warning(
                "The supplied tracking code isn't associated with the orderId. Returning generic message."
            )
            delivery_details = f"The provided tracking code {tracking_code} and order {order_id} don't seem to match. No results retrieved."
    else:
        logging.warning("The order with orderId %s doesn't exist.", order_id)
        delivery_details = f"The order with orderId {order_id} doesn't exist. Please check the provided orderId."
    return delivery_details


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Entrypoint for the function app"""
    logging.info("Python function started...")
    logging.info(
        "Python HTTP trigger function processed a request. originating from ip address: %s.",
        req.headers.get("X-FORWARDED-FOR"),
    )
    action = req.params.get("action")
    order_id = req.params.get("orderid")
    tracking_code = req.params.get("trackingcode")
    if not action or not order_id:
        return func.HttpResponse(
            "Please provide an <action> parameter and an <orderid> parameter.",
            status_code=200,
        )

    match action:
        case "status":
            order_status = get_order_status(order_id)
            return func.HttpResponse(order_status, status_code=200)
        case "details":
            if not tracking_code:
                return func.HttpResponse(
                    "Please provide your trackingcode associated with the order that you want to track.",
                    status_code=200,
                )
            order_delivery_details = get_order_delivery_details(order_id, tracking_code)
            return func.HttpResponse(order_delivery_details, status_code=200)
        case _:
            return func.HttpResponse(
                'Please provide a valid <action> property, like "status" or "details".',
                status_code=200,
            )
