import logging
import json
import os
import azure.functions as func
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.data.tables import TableClient


def fetch_order_details(order_id: str):
    """Function to fetch details based on orderId"""
    credential = DefaultAzureCredential()
    storage_account_name = os.getenv("AzureWebJobsStorage__accountName")
    table_client = TableClient(
        endpoint=f"https://{storage_account_name}.table.core.windows.net/",
        credential=credential,
        table_name="ordertracking",
    )
    try:
        order_details = table_client.get_entity(partition_key="order", row_key=order_id)
    except ResourceNotFoundError:
        logging.info("Failed to find entity in table storage")
        order_details = None
    return order_details


def get_order_status(order_id: str):
    """Function to retrieve the latest status of an order"""
    logging.info("Fetching the latest status of order %s.", order_id)
    # Setting default value
    return_time = f"The order with orderId {order_id} doesn't exist. Please check the provided orderId."
    order_details = fetch_order_details(order_id)
    if order_details is not None:
        match order_details["status"]:
            case "Development":
                return_time = f"Order {order_id} is currently in development. Our team will contact you when your software is ready to begin testing.."
            case "Testing":
                return_time = f"Order {order_id} is currently being tested. Once testing finishes, the product will be shipped to the hub."
            case "Shipped":
                return_time = f"Order {order_id} has already been shipped and can be downloaded from the hub."
    logging.info(return_time)
    return return_time


def get_order_delivery_details(order_id: str, tracking_code: str):
    """Function to retrieve the delivery details of an order"""
    logging.info(
        "Details of %s requested, validating supplied tracking code %s...",
        order_id,
        tracking_code,
    )
    order_details = fetch_order_details(order_id)
    if order_details is not None:
        supplied_correct_tracking_code = eval(
            "%s == %s" % (order_details["tracking_code"], tracking_code)
        )
        if supplied_correct_tracking_code:
            logging.info(
                "The supplied tracking code is correct. Returning order details!"
            )
            delivery_details = json.dumps(order_details)
        else:
            logging.warning(
                "The supplied tracking code isn't associated with the orderId. Returning generic message."
            )
            delivery_details = f"The provided tracking code {tracking_code} and order {order_id} don't seem to match. No results retrieved."
    else:
        logging.warning("The order with orderId %s doesn't exist.", order_id)
        delivery_details = f"The order with orderId {order_id} doesn't exist. Please check the provided orderId."
    return delivery_details


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Entrypoint for the function app"""
    logging.info("Python function started...")
    logging.info(
        "Python HTTP trigger function processed a request. originating from ip address: %s.",
        req.headers.get("X-FORWARDED-FOR"),
    )
    action = req.params.get("action")
    order_id = req.params.get("orderid")
    tracking_code = req.params.get("trackingcode")
    if not action or not order_id:
        return func.HttpResponse(
            "Please provide an <action> parameter and an <orderid> parameter.",
            status_code=200,
        )

    match action:
        case "status":
            order_status = get_order_status(order_id)
            return func.HttpResponse(order_status, status_code=200)
        case "details":
            if not tracking_code:
                return func.HttpResponse(
                    "Please provide your trackingcode associated with the order that you want to track.",
                    status_code=200,
                )
            order_delivery_details = get_order_delivery_details(order_id, tracking_code)
            return func.HttpResponse(order_delivery_details, status_code=200)
        case _:
            return func.HttpResponse(
                'Please provide a valid <action> property, like "status" or "details".',
                status_code=200,
            )
